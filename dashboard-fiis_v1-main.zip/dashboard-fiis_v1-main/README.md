# dashboard-fiis
Dashboard para análise de FIIs para renda passiva
